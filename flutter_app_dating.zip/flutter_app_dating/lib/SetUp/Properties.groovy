package SetUp

class Properties {

}
